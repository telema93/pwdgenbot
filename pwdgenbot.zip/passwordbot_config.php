<?php
return [
    'bot_token' => 'YOUR_BOT_TOKEN_HERE',
    'admin_id' => 123456789, // замените на ваш Telegram ID
    'db' => [
        'host' => 'localhost',
        'dbname' => 'your_db_name',
        'user' => 'your_db_user',
        'pass' => 'your_db_pass'
    ]
];